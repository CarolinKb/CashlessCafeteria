package com.ccashhlesscafeteria.cashlesscafeteria;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;
import java.util.prefs.Preferences;



public class Abrufen extends AppCompatActivity {

    Button btnGuthabenladen;
    EditText etCodeeingeben;
    TextView StartAbrufen, tvGuthaben, tvCodeeingeben, etGuthabenbetrag, tvCode;
    String code;
    int guthaben=2;
    private String[] codes = new String[10];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getApplicationContext()
        SharedPreferences sharedPref = getSharedPreferences("guthabenPreferences",0);
        guthaben = sharedPref.getInt("guthaben",0);
        setContentView(R.layout.abrufen);
        StartAbrufen = findViewById(R.id.StartAbrufen);
        etGuthabenbetrag = findViewById(R.id.etGuthabenbetrag);
        etCodeeingeben = findViewById(R.id.etCodeeingeben);
        tvGuthaben = findViewById(R.id.tvGuthaben);
        btnGuthabenladen = findViewById(R.id.btnGuhabenladen);
        tvCode = findViewById(R.id.tvCode);
        tvCodeeingeben = findViewById(R.id.tvCodeeingeben);




        etGuthabenbetrag.setText(guthaben + "Euro");

        if (codes[9] == null) {
            for (int i = 0; i < 10; i++) {
                final int min = 1409432;
                final int max = 9833091;

                final int random = new Random().nextInt((max - min) + 1);
                codes[i] = random + "";
            }
        }
        tvCode.setText(codes[1]);
        btnGuthabenladen.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                code = String.valueOf(etCodeeingeben.getText().toString());

                for (int i = 0; i < 10; i++) {
                    if (!code.equals(0 + "")) {
                        if (code.equals(codes[1])) {
                            changeGuthaben(10);
                            codes[1] = 0+"";
                            etGuthabenbetrag.setText(guthaben + "Euro");
                            Toast.makeText(Abrufen.this,"Das Guthaben wurde um 10 Euro erhöht",Toast.LENGTH_SHORT).show();
                        }
                        else {
                            Toast.makeText(Abrufen.this,"Der Guthabencode ist fehlerhaft",Toast.LENGTH_SHORT).show();

                        }

                        break;
                    }
                }

            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        getApplication().
        SharedPreferences sharedPref = getSharedPreferences("guthabenPreferences",0);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt("guthaben",Guthabenabrufen());
        editor.apply();

    }
    public int Guthabenabrufen() {
        return guthaben;
    }

    public  void changeGuthaben(int pguthaben) {
        guthaben = guthaben + pguthaben;

    }


    public void setGuthaben(int pguthaben) {
        guthaben = pguthaben;
    }
}