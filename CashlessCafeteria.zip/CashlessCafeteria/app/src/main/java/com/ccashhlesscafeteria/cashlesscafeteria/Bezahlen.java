package com.ccashhlesscafeteria.cashlesscafeteria;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;
import java.util.Calendar;




public class Bezahlen extends AppCompatActivity {


    EditText StartBezahlen;
    Button btnBezahlen, btnTest;
    String[] essenanzeigen = new String[5];
    static String essensehen = "";
    String codesehen = "";
    int geldbetrag;
    Abrufen Bchangeguthaben = new Abrufen();




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences sharedPref = getSharedPreferences("guthabenPreferences", MODE_PRIVATE);
        Bchangeguthaben.setGuthaben(sharedPref.getInt("guthaben", 0));
        setContentView(R.layout.bezahlen);
        StartBezahlen = findViewById(R.id.StartBezahlen);
        btnBezahlen = findViewById(R.id.btnBezahlen);
        for (int i = 0; i < essenanzeigen.length; i++) {
            essenanzeigen[i] = "";
        }
        final ArrayList<List_Bezahlen> essen = new ArrayList<List_Bezahlen>();
        essen.add(new List_Bezahlen("Thunfisch Brötchen", "2€"));
        essen.add(new List_Bezahlen("Laugenbrötchen", "1€"));
        essen.add(new List_Bezahlen("belegtes Laugenbrötchen", "2€"));
        essen.add(new List_Bezahlen("Cookie", "1€"));
        essen.add(new List_Bezahlen("Schokocroissant", "1€"));
        AdapterBezahlen essenAdapter = new AdapterBezahlen(this, essen);
        ListView listEssenBezahlen = (ListView)
                findViewById(R.id.listBezahlen);
        listEssenBezahlen.setAdapter(essenAdapter);
        btnBezahlen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final int min = 10;
                final int max = 99;
                final int random = new Random().nextInt((max - min) + 1);
                final int random2 = new Random().nextInt((max - min) + 1);
                final int random3 = new Random().nextInt((max - min) + 1);
                codesehen = random + "" + Calendar.DAY_OF_MONTH + "" + Calendar.MINUTE + "" + random2 + "" + Calendar.DATE + "" + Calendar.HOUR_OF_DAY + "" + random3 + "";
                setContentView(R.layout.essen_anzeigen);
                TextView Essenzeigen = (TextView) findViewById(R.id.tvEssenzeigen);
                Intent inEssenanzeigen = new Intent(Bezahlen.this, Essen_Anzeigen.class);
                ((ViewGroup) Essenzeigen.getParent()).removeView(Essenzeigen);
                for (int i = 0; i < essenanzeigen.length; i++) {
                    if (essenanzeigen[i] != "") {
                        essensehen = essensehen + "---" + essenanzeigen[i];
                    }
                }
                essensehen=essensehen+"---"+codesehen+"---Betrag:"+geldbetrag+"Euro";

                Essenzeigen.setText(essensehen);
                setContentView(Essenzeigen);
                startActivity(inEssenanzeigen);



            }
        });

        listEssenBezahlen.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        if (Bchangeguthaben.Guthabenabrufen() >= 2) {

                            Toast.makeText(Bezahlen.this, "Thunfisch Brötchen wurde hinzugefügt", Toast.LENGTH_SHORT).show();
                            Bchangeguthaben.changeGuthaben(-2);
                            geldbetrag=geldbetrag+2;
                            for (int j = 0; i < essenanzeigen.length; j++) {
                                if (essenanzeigen[j] == "") {
                                    essenanzeigen[j] = "Thunfisch Brötchen";
                                    break;
                                }
                            }
                            break;
                        } else {
                            Toast.makeText(Bezahlen.this, "Das Guthaben reicht nicht aus", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    case 1:
                        if (Bchangeguthaben.Guthabenabrufen() >= 1) {
                            Toast.makeText(Bezahlen.this, "Laugenbrötchen wurde hinzugefügt", Toast.LENGTH_SHORT).show();
                            Bchangeguthaben.changeGuthaben(-1);
                            geldbetrag=geldbetrag+1;
                            for (int j = 0; i < essenanzeigen.length; j++) {
                                if (essenanzeigen[j] == "") {
                                    essenanzeigen[j] = "Laugenbrötchen";
                                    break;
                                }
                            }
                            break;
                        } else {
                            Toast.makeText(Bezahlen.this, "Das Guthaben reicht nicht aus", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    case 2:
                        if (Bchangeguthaben.Guthabenabrufen() >= 2) {
                            Toast.makeText(Bezahlen.this, "belegtes Laugenbrötchen wurde hinzugefügt", Toast.LENGTH_SHORT).show();
                            Bchangeguthaben.changeGuthaben(-2);
                            geldbetrag=geldbetrag+2;
                            for (int j = 0; i < essenanzeigen.length; j++) {
                                if (essenanzeigen[j] == "") {
                                    essenanzeigen[j] = "belegtes Laugenbrötchen";
                                    break;
                                }
                            }
                            break;
                        } else {
                            Toast.makeText(Bezahlen.this, "Das Guthaben reicht nicht aus", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    case 3:
                        if (Bchangeguthaben.Guthabenabrufen() >= 2) {
                            Toast.makeText(Bezahlen.this, "Cookie wurde hinzugefügt", Toast.LENGTH_SHORT).show();
                            Bchangeguthaben.changeGuthaben(-2);
                            geldbetrag=geldbetrag+2;
                            for (int j = 0; i < essenanzeigen.length; j++) {
                                if (essenanzeigen[j] == "") {
                                    essenanzeigen[j] = "Cookie";
                                    break;
                                }
                            }
                            break;
                        } else {
                            Toast.makeText(Bezahlen.this, "Das Guthaben reicht nicht aus", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    case 4:
                        if (Bchangeguthaben.Guthabenabrufen() >= 1) {
                            Toast.makeText(Bezahlen.this, "Schokocroissant wurde hinzugefügt", Toast.LENGTH_SHORT).show();
                            Bchangeguthaben.changeGuthaben(-1);
                            geldbetrag=geldbetrag+1;
                            for (int j = 0; i < essenanzeigen.length; j++) {
                                if (essenanzeigen[j] == "") {
                                    essenanzeigen[j] = "Schokocroissant";
                                    break;
                                }
                            }
                            break;
                        } else {
                            Toast.makeText(Bezahlen.this, "Das Guthaben reicht nicht aus", Toast.LENGTH_SHORT).show();
                            break;
                        }
                }
            }

        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SharedPreferences sharedPref = getApplication().getSharedPreferences("guthabenPreferences", 0);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt("guthaben", Bchangeguthaben.Guthabenabrufen());
        editor.apply();
    }
}