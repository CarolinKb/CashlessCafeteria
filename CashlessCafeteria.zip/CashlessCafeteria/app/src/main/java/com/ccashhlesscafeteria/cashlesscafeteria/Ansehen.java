package com.ccashhlesscafeteria.cashlesscafeteria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.ccashhlesscafeteria.cashlesscafeteria.AllergenenAnzeigen;

import java.util.ArrayList;

public class Ansehen  extends AppCompatActivity {

    EditText StartNachschlagen;
    ListView listAnsehen;
    boolean vegetarisch = false;
    boolean vegan = false;
    boolean glutenfrei = false;
    boolean schweinefrei = false;
    String tvegetarisch;
    String tglutenfrei;
    String tvegan;
    String tschweinefrei;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ansehen);
        StartNachschlagen = findViewById(R.id.StartNachschlagen);
        final ArrayList<List_Bezahlen> essen = new ArrayList<List_Bezahlen>();

        essen.add(new List_Bezahlen("Thunfisch Brötchen", "1,80"));
        essen.add(new List_Bezahlen("Laugenbrötchen", "1,00"));
        essen.add(new List_Bezahlen("belegtes Laugenbrötchen", "1,70"));
        essen.add(new List_Bezahlen("Cookie", "1,60"));
        essen.add(new List_Bezahlen("Schokocroissant", "1,20"));

        AdapterBezahlen essenAdapter = new AdapterBezahlen(this, essen);
        ListView  listEssenAnsehen = (ListView)
                findViewById(R.id.listAnsehen);
        listEssenAnsehen.setAdapter(essenAdapter);

        listEssenAnsehen.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                setContentView(R.layout.allergenen_anzeigen);
                TextView Allergenenzeigen= (TextView) findViewById(R.id.tvAllergenen);
                ((ViewGroup) Allergenenzeigen.getParent()).removeView(Allergenenzeigen);
                Intent inEssenansehen = new Intent(Ansehen.this, AllergenenAnzeigen.class);

                switch (i) {
                    case 0:
                        schweinefrei=true;
                            break;

                    case 1:

                        vegetarisch=true;
                        vegan=true;
                        schweinefrei=true;
                        break;

                    case 2:
                        vegetarisch=true;
                        schweinefrei=true;
                        break;

                    case 3:
                        vegetarisch=true;
                        schweinefrei=true;
                        break;

                    case 4:
                        vegetarisch=true;
                        schweinefrei=true;
                        break;
                }
                if(vegetarisch==false) {
                    tvegetarisch="Das Produkt ist nicht vegetarisch";

                }
                else{
                    tvegetarisch="Das Produkt ist vegetarisch";

                }
                if(schweinefrei==false) {
                    tschweinefrei="Das Produkt ist mit Schwein";

                }
                else{
                   tschweinefrei="Das Produkt ist ohne Schwein";

                }

                if(vegan==false) {
                    tvegan="Das Produkt ist nicht vegan";
                }
                else{
                    tvegan="Das Produkt ist vegan";
                }
                if(glutenfrei==false){
                    tglutenfrei="Das Produkt ist nicht glutenfrei";
                }
                else{
                    tglutenfrei="Das Produkt ist glutenfrei";
                }

                Allergenenzeigen.setText(tglutenfrei+"-"+
                tvegetarisch+"-"+
                        tvegan+"-"+tschweinefrei);
                setContentView(Allergenenzeigen);


                    startActivity(inEssenansehen);
            }

        });
            }
        }
