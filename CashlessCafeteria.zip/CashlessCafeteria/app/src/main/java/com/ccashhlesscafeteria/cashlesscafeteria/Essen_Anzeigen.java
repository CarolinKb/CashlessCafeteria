package com.ccashhlesscafeteria.cashlesscafeteria;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Essen_Anzeigen extends AppCompatActivity {
    TextView tvEssenzeigen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.essen_anzeigen);
        tvEssenzeigen = findViewById(R.id.tvEssenzeigen);
    }
}