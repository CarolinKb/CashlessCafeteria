package com.ccashhlesscafeteria.cashlesscafeteria;
import android.app.Activity;
import android.view.LayoutInflater;
import android.widget.ArrayAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.ArrayList;

public class AdapterBezahlen extends ArrayAdapter<List_Bezahlen> {

    private static final String LOG_TAG = AdapterBezahlen.class.getSimpleName();


    public AdapterBezahlen(Activity context, ArrayList<List_Bezahlen> essen){
        super(context,0, essen);
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View listItemView = convertView;
        if(listItemView== null){
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.bezahlen_liste, parent,false);
        }

        List_Bezahlen currentEssen = getItem(position);
        TextView listessen = (TextView)
                listItemView.findViewById(R.id.listessen);
        listessen.setText(currentEssen.getessen());

        TextView listpreis = (TextView)
                listItemView.findViewById(R.id.listpreis);
        listpreis.setText(String.valueOf(currentEssen.getpreis()));

        return listItemView;

    }

}


