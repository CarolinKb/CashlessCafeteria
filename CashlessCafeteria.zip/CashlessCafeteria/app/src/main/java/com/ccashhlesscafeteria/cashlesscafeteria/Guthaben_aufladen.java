package com.ccashhlesscafeteria.cashlesscafeteria;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class Guthaben_aufladen  extends AppCompatActivity {
    private int[] codes = new int [10];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        for(int i=0; i<10;i++){
            final int min = 1409432;
            final int max = 9833091;
            final int random = new Random().nextInt((max-min)+1);
            codes[i]= random;
        }



    }
}
