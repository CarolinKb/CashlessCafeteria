package com.ccashhlesscafeteria.cashlesscafeteria;

import java.util.ArrayList;

public class List_Bezahlen {
    private String listpreis;
    private String listessen;

    public List_Bezahlen(String plistpreis, String plistessen){
      listpreis = plistpreis;
      listessen = plistessen;



    }
    public String getpreis(){
        return listpreis;

    }
    public String getessen(){
        return listessen;

    }

}
