package com.ccashhlesscafeteria.cashlesscafeteria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Hauptmenu extends AppCompatActivity {
    private Button btnBezahlen, btnHilfe, btnAusloggen, btnAbrufen, btnNachschlagen;
    EditText StartHauptmenü, etEssen, etGuthaben, etAnderes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.hauptmenue);
        btnBezahlen = findViewById(R.id.btnBezahlen);
        btnAbrufen = findViewById(R.id.btnAbrufen);

        btnHilfe = findViewById(R.id.btnHilfe);
        btnAusloggen = findViewById(R.id.btnAusloggen);
        btnNachschlagen = findViewById(R.id.btnNachschlagen);
        StartHauptmenü = findViewById(R.id.StartHauptmenü);
        etEssen = findViewById(R.id.etEssen);
        etGuthaben = findViewById(R.id.etGuthaben);
        etAnderes = findViewById(R.id.etAnderes);
        btnBezahlen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inBezahlen = new Intent(Hauptmenu.this, Bezahlen.class);
                startActivity(inBezahlen);

            }
        });
        btnAbrufen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inAbrufen = new Intent(Hauptmenu.this, Abrufen.class);
                startActivity(inAbrufen);

            }
        });
        btnNachschlagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inNachschlagen = new Intent(Hauptmenu.this, Ansehen.class);
                startActivity(inNachschlagen);

            }
        });
        btnAusloggen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inAusloggen = new Intent(Hauptmenu.this, Login.class);
                startActivity(inAusloggen);

            }
        });

        btnHilfe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inHilfe = new Intent(Hauptmenu.this, Hilfe.class);
                startActivity(inHilfe);

            }
        });





    }
}



