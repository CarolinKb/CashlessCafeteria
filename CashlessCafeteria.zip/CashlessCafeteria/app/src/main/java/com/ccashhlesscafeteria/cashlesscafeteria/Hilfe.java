package com.ccashhlesscafeteria.cashlesscafeteria;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Hilfe extends AppCompatActivity {
    TextView Frage1,Frage2,Frage3,Antwort1,Antwort2,Antwort3,Antwort4,Antwort5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hilfe);
        Frage1 = findViewById(R.id.tvFrage1);
        Frage2 = findViewById(R.id.tvFrage2);
        Frage3 = findViewById(R.id.tvFrage3);
        Antwort1 = findViewById(R.id.tvAntwort1);
        Antwort2 = findViewById(R.id.tvAntwort2);
        Antwort3 = findViewById(R.id.tvAntwort3);
        Antwort4 = findViewById(R.id.tvAntwort4);
        Antwort5 = findViewById(R.id.tvAntwort5);

    }

}

