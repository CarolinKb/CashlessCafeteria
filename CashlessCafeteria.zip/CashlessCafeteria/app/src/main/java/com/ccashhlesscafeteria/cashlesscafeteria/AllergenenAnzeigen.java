package com.ccashhlesscafeteria.cashlesscafeteria;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AllergenenAnzeigen extends AppCompatActivity{
    TextView tvAllergenen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.allergenen_anzeigen);
        tvAllergenen = findViewById(R.id.tvAllergenen);

    }

}