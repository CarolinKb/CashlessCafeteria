package com.ccashhlesscafeteria.cashlesscafeteria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
    TextView tvPasswort, tvEmail;
    EditText etEmail, etPasswort, StartLogin;
    Button btnEinloggen, btnRegistrieren;
    Abrufen Csetguthaben = new Abrufen();

    @Override
    protected void onCreate  (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        btnEinloggen = findViewById(R.id.btnEinloggen);
        etEmail = findViewById(R.id.etEmail);
        etPasswort = findViewById(R.id.etPasswort);
        tvPasswort = findViewById(R.id.tvPasswort);
        tvEmail = findViewById(R.id.tvEmail);
        StartLogin = findViewById(R.id.StartLogin);
        btnRegistrieren = findViewById(R.id.btnRegistrieren);


        btnEinloggen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inLogin = new Intent(Login.this, Hauptmenu.class);
                startActivity(inLogin);
            }

            });
        btnRegistrieren.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inRegistrieren = new Intent(Login.this,Hauptmenu.class);
                startActivity(inRegistrieren);
                Csetguthaben.setGuthaben(0);
            }
        });


    }
}
 